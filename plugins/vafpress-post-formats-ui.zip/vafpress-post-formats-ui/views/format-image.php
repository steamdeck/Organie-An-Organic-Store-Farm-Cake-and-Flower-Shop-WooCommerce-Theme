<div id="vp-pfui-format-image-preview" class="vp-pfui-tab-content vp-pfui-elm-block" style="display: none;">
	Pick an image in Featured Image section
</div>
